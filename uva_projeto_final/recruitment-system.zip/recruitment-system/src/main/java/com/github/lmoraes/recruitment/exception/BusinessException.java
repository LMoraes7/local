package com.github.lmoraes.recruitment.exception;

public final class BusinessException extends RuntimeException {


}
