package com.github.lmoraes.recruitment.domain.model.step;

public interface StepApplication extends Step {
    InfoStepApplication getInfoStepApplication();
}
