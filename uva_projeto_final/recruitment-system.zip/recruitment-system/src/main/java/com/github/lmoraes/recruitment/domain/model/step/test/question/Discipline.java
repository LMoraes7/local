package com.github.lmoraes.recruitment.domain.model.step.test.question;

public enum Discipline {
    PORTUGUESE, MATH
}
