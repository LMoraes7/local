package com.github.lmoraes.recruitment.domain.model.application;

public enum Status {
    IN_PROGRESS, APPROVED, FAILED, CLOSED
}
