package com.github.lmoraes.recruitment.utils;

public interface SelectionProcessIdentifierGenerator {
    String generateIdentifierForSelectionProcess();
}
