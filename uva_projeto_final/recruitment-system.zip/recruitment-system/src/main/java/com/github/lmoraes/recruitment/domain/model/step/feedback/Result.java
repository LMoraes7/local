package com.github.lmoraes.recruitment.domain.model.step.feedback;

public enum Result {
    APPROVED, FAILED
}
