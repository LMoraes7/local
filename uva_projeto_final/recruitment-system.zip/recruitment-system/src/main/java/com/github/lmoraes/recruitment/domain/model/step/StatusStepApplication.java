package com.github.lmoraes.recruitment.domain.model.step;

public enum StatusStepApplication {
    WAITING_EXECUTION, EXECUTED , WAITING_RELEASE
}
