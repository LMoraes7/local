package com.github.lmoraes.recruitment.domain.model.employee;

public enum Role {
    ADMINISTRATOR, RECRUITER
}
