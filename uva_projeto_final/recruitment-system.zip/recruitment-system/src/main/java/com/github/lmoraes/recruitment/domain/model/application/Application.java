package com.github.lmoraes.recruitment.domain.model.application;

import com.github.lmoraes.recruitment.domain.model.candidate.Candidate;
import com.github.lmoraes.recruitment.domain.model.selective.process.SelectiveProcess;
import com.github.lmoraes.recruitment.domain.model.step.StepApplication;

import java.util.ArrayList;
import java.util.List;

import static com.github.lmoraes.recruitment.utils.IdentifierGeneratorService.generateIdentifierForApplication;

public final class Application {
    private final String id;
    private Status status;
    private final Candidate candidate;
    private final SelectiveProcess selectiveProcess;
    private final List<StepApplication> stepsApplication;

    public Application(final Candidate candidate, final SelectiveProcess selectiveProcess) {
        this.id = generateIdentifierForApplication();
        this.status = Status.IN_PROGRESS;
        this.candidate = candidate;
        this.selectiveProcess = selectiveProcess;
        this.stepsApplication = new ArrayList<>();
    }

    public void addStepsApplication(final List<StepApplication> stepsApplication) {
        this.stepsApplication.addAll(stepsApplication);
    }

}
