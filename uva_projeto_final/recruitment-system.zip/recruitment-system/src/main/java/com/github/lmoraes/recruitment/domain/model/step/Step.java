package com.github.lmoraes.recruitment.domain.model.step;

public interface Step {
    InfoStep getInfoStep();
}
