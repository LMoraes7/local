package com.github.lmoraes.sistema.rh.recrutamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecrutamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
