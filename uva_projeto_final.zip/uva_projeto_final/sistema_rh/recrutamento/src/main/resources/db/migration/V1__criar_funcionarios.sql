create table funcionarios(
	id varchar(13) not null primary key,
	nome varchar(255) not null,
	documento varchar(11) not null unique,
	email varchar(255) not null unique,
	telefones text[] not null,
	data_nascimento date not null,
	logradouro varchar(255) not null,
	numero integer null,
	complemento varchar(255) null,
	uf varchar(2) not null,
	cargo varchar(100) not null,
	salario numeric(8, 2) not null,
	data_contratacao date not null,
	codigo varchar(10) not null unique,
	senha varchar(10) not null,
	perfis_acesso text[] null
);

create table liderados_liderancas(
	ativa boolean not null,
	id_liderado varchar(13) not null,
	id_lideranca varchar(13) not null,
	constraint fk_liderado_liderancas foreign key (id_liderado) references funcionarios (id),
	constraint fk_lideranca_liderados foreign key (id_lideranca) references funcionarios (id)
);

create table candidatos(
	id varchar(13) not null primary key,
	nome varchar(255) not null,
	documento varchar(11) not null unique,
	email varchar(255) not null unique,
	telefones text[] not null,
	data_nascimento date not null,
	logradouro varchar(255) not null,
	numero integer null,
	complemento varchar(255) null,
	uf varchar(2) not null,
	codigo varchar(10) not null unique,
	senha varchar(10) not null,
	perfis_acesso text[] null
);

create table processos_seletivos(
	id varchar(13) not null primary key,
	titulo varchar(255) not null,
	descricao text not null,
	responsabilidades text[] not null,
	requisitos text[] not null,
	infos_adicionais text[] null,
	status varchar(100) not null,
	id_responsavel varchar(13) not null,
	constraint fk_processo_seletivo_responsavel foreign key (id_responsavel) references funcionarios (id)
);

create table etapas(
    id varchar(13) not null primary key,
    titulo varchar(255) not null,
    descricao text not null,
    tipo varchar(100) not null,
    tempo_limite bigint not null,
    id_processo_seletivo varchar(13) not null,
    constraint fk_processo_seletivo_etapa foreign key (id_processo_seletivo) references processos_seletivos (id)
);

create table candidaturas(
	id varchar(13) not null primary key,
	status varchar(100) not null,
	id_candidato varchar(13) not null,
	id_processo_seletivo varchar(13) not null,
	constraint fk_candidato_candidatura foreign key (id_candidato) references candidatos (id),
	constraint fk_processo_seletivo_candidatura foreign key (id_processo_seletivo) references processos_seletivos (id)
);

create table etapas_candidaturas(
    id_candidatura varchar(13) not null,
    id_etapa varchar(13) not null,
    status varchar(100) not null,
    resultado varchar(100) not null,
    data_liberacao date null,
    constraint fk_candidatura_etapa foreign key (id_candidatura) references candidaturas (id),
    constraint fk_etapa_candidatura foreign key (id_etapa) references etapas (id)
);

create table etapas_upload(
    id_etapa varchar(13) not null,
    id_candidatura varchar(13) not null,
    arquivo text not null,
    constraint fk_etapa_upload foreign key (id_etapa) references etapas (id),
    constraint fk_candidatura_etapa_upload foreign key (id_candidatura) references candidaturas (id),
);

create table etapas_provas(
    id varchar(13) not null,
    id_candidatura varchar(13) not null,
    constraint fk_etapa_provas foreign key (id_etapa) references etapas (id),
    constraint fk_candidatura_etapa_provas foreign key (id_candidatura) references candidaturas (id),
);

create table etapas_entrevista(
    id varchar(13) not null,
    id_candidatura varchar(13) not null,
    link text not null,
    instante timestamp not null,
    constraint fk_etapa_entrevista foreign key (id) references etapas (id),
    constraint fk_candidatura_etapa_entrevista foreign key (id_candidatura) references candidaturas (id),
);

create table questoes(
    id varchar(13) not null primary key,
    questao text not null,
    disciplina varchar(100) not null
);

create table respostas(
    id varchar(13) not null primary key,
    resposta text not null,
    correta boolean not null,
    id_questao varchar(100) not null,
    constraint fk_resposta_questao foreign key (id_questao) references questoes (id),
);