package com.github.lmoraes.recruitment.domain.model.selective.process;

public enum Status {
    IN_PROGRESS, CLOSED
}
