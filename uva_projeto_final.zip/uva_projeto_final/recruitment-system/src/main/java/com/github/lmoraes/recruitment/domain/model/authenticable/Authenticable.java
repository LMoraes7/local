package com.github.lmoraes.recruitment.domain.model.authenticable;

import com.github.lmoraes.recruitment.domain.model.vo.AccessCredentials;

public interface Authenticable {
    AccessCredentials getAccessCredentials();
}
