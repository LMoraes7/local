package com.github.lmoraes.recruitment.domain.model.selective.process;

public enum Position {
    ADMINISTRATOR, RECRUITER
}
