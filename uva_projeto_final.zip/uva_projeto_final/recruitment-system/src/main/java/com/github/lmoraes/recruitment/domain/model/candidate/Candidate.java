package com.github.lmoraes.recruitment.domain.model.candidate;

import com.github.lmoraes.recruitment.domain.model.application.Application;
import com.github.lmoraes.recruitment.domain.model.authenticable.Authenticable;
import com.github.lmoraes.recruitment.domain.model.selective.process.SelectiveProcess;
import com.github.lmoraes.recruitment.domain.model.vo.AccessCredentials;
import com.github.lmoraes.recruitment.domain.model.vo.PersonalData;
import com.github.lmoraes.recruitment.exception.BusinessException;
import com.github.lmoraes.recruitment.exception.NotFoundException;
import com.github.lmoraes.recruitment.repository.application.ApplicationRepository;

import java.util.Collections;
import java.util.List;

import static com.github.lmoraes.recruitment.domain.model.application.Status.CLOSED;
import static com.github.lmoraes.recruitment.domain.model.selective.process.Status.IN_PROGRESS;
import static com.github.lmoraes.recruitment.usecase.application.conveter.ConverterHelper.buildApplication;

public class Candidate implements Authenticable {
    protected final String id;
    protected final PersonalData personalData;
    protected final AccessCredentials accessCredentials;
    protected final List<Application> applications;

    public Candidate(
            final String id,
            final PersonalData personalData,
            final AccessCredentials accessCredentials,
            final List<Application> applications
    ) {
        this.id = id;
        this.personalData = personalData;
        this.accessCredentials = accessCredentials;
        this.applications = applications;
    }

    @Override
    public AccessCredentials getAccessCredentials() {
        return accessCredentials;
    }

    public Application applyForTheSelectionProcess(
            final SelectiveProcess selectiveProcess,
            final ApplicationRepository applicationRepository
    ) {
        if (selectiveProcess.getStatus() != IN_PROGRESS)
            throw new BusinessException();

        final var application = buildApplication(this, selectiveProcess);
        applicationRepository.register(application);

        return application;
    }

    public List<Application> getLightApplications() {
        return Collections.unmodifiableList(applications);
    }

    public void closeApplication(
            final String applicationId,
            final ApplicationRepository applicationRepository
    ) {
        final var updateApplication = applicationRepository.updateStatusByApplicationIdAndCandidateId(
                applicationId,
                this.id,
                CLOSED
        );

        if (updateApplication != 0)
            throw new NotFoundException(Application.class, applicationId);
    }

    public Application getSpecificApplication(
            final String applicationId,
            final ApplicationRepository applicationRepository
    ) {
        return applicationRepository.getByIdAndCandidateId(applicationId, this.id)
                .orElseThrow(() -> new NotFoundException(Application.class, applicationId));
    }

}
