package com.github.lmoraes.recruitment.domain.model.step.upload;

public enum FileType {
    PDF, MP4
}
